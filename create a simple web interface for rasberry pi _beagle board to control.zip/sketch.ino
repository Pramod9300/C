#include <WiFi.h>
#include <WebServer.h>

WebServer server(80);

int led = 2;

void setup() {
  pinMode(led, OUTPUT);

  WiFi.begin("Wokwi-GUEST", "");

  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
  }

  // Home Page
  server.on("/", []() {
    server.send(200, "text/html",
                "<h1>ESP32 LED Control</h1>"
               "<a href='/on'>ON</a><br>"
                "<a href='/off'>OFF</a>");
  });

  // LED ON
  server.on("/on", []() {
    digitalWrite(led, HIGH);
    server.send(200, "text/html", "LED ON");
  });

  // LED OFF
  server.on("/off", []() {
    digitalWrite(led, LOW);
    server.send(200, "text/html", "LED OFF");
  });

  server.begin();
}

void loop() {
  server.handleClient();
}